# Integrantes del grupo

- [Andre Lopez Taranco](Lopez/Lopez.md)
- [Mario Cartolin](Cartolin/Cartolin.md)
- [George Zuñiga](Zuñiga/Zuñiga.md)
- [Alejandro Gómez López](Gómez/Gómez.md)
- [Abraham Bustíos Terres](Bustios/Bustios.md)
- [Aaron Livias Vigil](Livias/Livias.md)

[Regresar al índice](../README.md)
